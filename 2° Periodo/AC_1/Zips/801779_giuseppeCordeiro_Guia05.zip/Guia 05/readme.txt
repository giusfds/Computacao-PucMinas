.V

theldo, nso arquivos .v, tem 2 modulos presentes deles, poius eu juntei os arquivos em um so.
um eu suava para teste e o outro para a funcao

.CIRC
na questao 05, nao entendi muito bom como que tinha que fazer, tentei o meu melhor