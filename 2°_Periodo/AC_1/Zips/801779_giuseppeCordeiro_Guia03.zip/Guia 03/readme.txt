acho que durante o txt com as atividades, da para perceber que eu to ficando com sono, assim o passo 
a passo esta ficando cada vez maior e mais explicado por caisa disso, sao 2:40 da manha e eu to aqui fazendo guia...
fiquei sem sono kkkkkkkk


atualizaccao:
nao consegui fazer direito a questao 5, a parte do verilog dela eua chei meio confusa
