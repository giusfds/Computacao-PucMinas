(05/08)
estou tendo dificuldades na questao 1B, pois nao consigo fazer mostrar a parte fracionada de forma correta. 
nao consegui achar o erro. alem disso, ele nao aceita uma matriz, para funcioanr tem que trocar a variavel que altera,
no meu caso o x, para que o display possa funcionar
